# Extension Icons

This folder should contain the extension icons in the following sizes:
- icon16.png (16x16 pixels)
- icon48.png (48x48 pixels)
- icon128.png (128x128 pixels)

## Creating Icons

You can create icons using any graphics editor. Here are some suggestions:

### Icon Design Ideas:
1. A ruler with both imperial and metric markings
2. A conversion arrow symbol (⇄) with measurement symbols
3. A simple "U→M" or "I⇄M" text logo
4. A combination of measurement units (in/mm)

### Quick Icon Creation Options:

**Option 1: Use an online icon generator**
- Visit https://www.favicon-generator.org/
- Upload your design or use text
- Generate all required sizes

**Option 2: Use a design tool**
- Figma, Inkscape, or Adobe Illustrator
- Create a 128x128 design
- Export as PNG in all three sizes

**Option 3: Simple SVG placeholder**
- Create a simple design in an SVG editor
- Convert to PNG using an online tool

### Temporary Solution:
For development, you can use solid color squares as placeholders:
- Create 16x16, 48x48, and 128x128 PNG files
- Use a distinctive color (e.g., blue #2563eb)
- Add simple text like "UC" (Unit Converter)

The extension will work without icons, but Chrome will display a default placeholder.
